
# Preparing 5-Node Kubernetes Cluster

### Anayeli Monserrat Hernandez Herrera - Cesar Sebastian Mera Pérez

## INTRODUCCIÓN 
Como sabemos un clúster de Kubernetes es un conjunto de máquinas de nodos que ejecutan aplicaciones en contenedores. Si ejecuta Kubernetes, está ejecutando un clúster. Por otra parte un nodo puede ser una máquina virtual o física, dependiendo del tipo de clúster. Cada nodo está gestionado por el componente máster y contiene los servicios necesarios para ejecutar pods. <br>
Un clúster contiene, como mínimo, un plano de control y una o varias máquinas informáticas o nodos. El plano de control es el encargado de mantener el estado deseado del clúster y de controlar, por ejemplo, las aplicaciones que se ejecutan y las imágenes de contenedores que se utilizan, en nuestro caso se tendra en control por medio de un token se que se pondrá en cada nodo. <br>
La ventaja más importante de Kubernetes es la capacidad de programar y ejecutar los contenedores en un grupo de máquinas, ya sean físicas o virtuales, en las instalaciones o en la nube, y esto es posible gracias al clúster. 

## Objetivos
### Objetivo general
El objetivo de esta práctica es que una vez que has creado el objeto, el sistema de Kubernetes se pondrá en marcha para asegurar que el objeto existe. Al crear un nodo, de indicara al nodo principal cómo será la carga de trabajo y la conexion dentro del clúster.<br>
### Objetivo especificos
- Qué exista conexión dentro de los nodos que corren en contenedores.<br>
- Los recursos disponibles para dichas aplicaciones.<br>

# Procedimiento y Resultados

1.  Primero abrimos el navegador y nos dirigimos al siguiente enlace para poder desarrollar la practica en "Play with Kubernetes"
## Preparing 5-Node Kubernetes Cluster
To get started with Kubernetes, follow the below steps:

- Open https://play-with-k8s.com on your browser

Click on Add Instances to setup first k8s node cluster
- Una vez dentro insertamos el siguiente comando.
## Run the below command:

```
kubeadm init --apiserver-advertise-address $(hostname -i)
mkdir -p $HOME/.kube
chown $(id -u):$(id -g) $HOME/.kube/config
kubectl apply -n kube-system -f \
    "https://cloud.weave.works/k8s/net?k8s-version=$(kubectl version | base64 |tr -d '\n')"
```
Este comando nos sirve para iniciar el dspliegue ne nuestro cluster de kubernetes de una manera sencilla.
![Esta es una imagen de ejemplo](1.png)

2. Agregamos 4 nuevos nodos.
## Adding New K8s Cluster Node
Agregramos 4 nuevas instancias las cuales serán los nodos que conformarán parte de nuestro cluster y debemos esperar un tiempo, aproximadamente 1 minuto a que terminen de completarse su proceso.<br>

Click on ```Add Instances``` to setup first k8s node cluster

Wait for 1 minute time till it gets completed. <br>
![Esta es una imagen de ejemplo](1.2.png) <br>
Copy the command starting with ```kubeadm join .....``` We will need it to be run on the worker node.

3. Pomemos en token en cada nodo.
## Setting up Worker Node

Click on ```Add New Instance``` and paste the last ```kubeadm``` command on this fresh new worker node.

```
[node2 ~]$ kubeadm join --token 4f924f.14eb7618a20d2ece 192.168.0.8:6443 --discovery-token-ca-cert-hash  sha256:a5c25aa4573e06a0c11b11df23c8f85c95bae36cbb07d5e7879d9341a3ec67b
```
You will see the below output:
```
[kubeadm] WARNING: kubeadm is in beta, please do not use it for production clusters.
[preflight] Skipping pre-flight checks[discovery] Trying to connect to API Server "192.168.0.8:6443"
[discovery] Created cluster-info discovery client, requesting info from "https://192.168.0.8:6443"
[discovery] Requesting info from "https://192.168.0.8:6443" again to validate TLS against the pinned public key
[discovery] Cluster info signature and contents are valid and TLS certificate validates against pinned roots, will use API Server "192.168.0.8:6443"[discovery] Successfully established connection with API Server "192.168.0.8:6443"
[bootstrap] Detected server version: v1.8.15
[bootstrap] The server supports the Certificates API (certificates.k8s.io/v1beta1)
Node join complete:
* Certificate signing request sent to master and response
  received.
* Kubelet informed of new secure connection details.

Run 'kubectl get nodes' on the master to see this machine join.
[node2 ~]$
```
Es necesario poner en cada nodo el token que nos arrojó el nodo principal, para que de esta manera pueda haber comunicación en el cluster.
![Esta es una imagen de ejemplo](2.2_token.png)<br>
Ponemos el token en cada nodo <br>
![Esta es una imagen de ejemplo](3.1_ponemos%20el%20token%20en%20el%20nodo.png)

4. Verificamos 
## Verifying Kubernetes Cluster

Run the below command on master node
```
[node1 ~]$ kubectl get nodes
NAME      STATUS    ROLES     AGE       VERSION
node1     Ready     master    15m       v1.10.2
node2     Ready     <none>    1m        v1.10.2
[node1 ~]$
```
## Adding Worker Nodes
```
[node1 ~]$ kubectl get nodes
NAME      STATUS    ROLES     AGE       VERSION
node1     Ready     master    58m       v1.10.2
node2     Ready     <none>    57m       v1.10.2
node3     Ready     <none>    57m       v1.10.2
node4     Ready     <none>    57m       v1.10.2
node5     Ready     <none>    54s       v1.10.2

```
Ponemos el comando anterior "get nodes" y como podemos observar todos los nodos están listos para funcionar.<br>
![Esta es una imagen de ejemplo](6%20nodos%20en%20redy.png)<br>
```
[node1 istio]$ kubectl get po
No resources found.
```
De la misma manera ejecutamos el comando "get po".
![Esta es una imagen de ejemplo](get%20po.png)<br>
```
[node1 ]$ kubectl get svc
NAME         TYPE        CLUSTER-IP   EXTERNAL-IP   PORT(S)   AGE
kubernetes   ClusterIP   10.96.0.1    <none>        443/TCP   1h
[node1] $
```
Y de igual manera ejecutamos el comando "get svc" para comprobar la conexión con el cluster y el puerto que está utilizando.
![Esta es una imagen de ejemplo](get%20svc.png)<br>

5. Mostramos los archivos .json
## Show the capacity of all our nodes as a stream of JSON objects
```
kubectl get nodes -o json |
      jq ".items[] | {name:.metadata.name} + .status.capacity"
```
Con este comando podremos observar la capacidad que contienen nuestros nodos como transmisores de objetos.
![Esta es una imagen de ejemplo](json.png)<br>

5. Accesamos a los espacios de nombre.
## Accessing namespaces
By default, ```kubectl``` uses the default namespace. We can switch to a different namespace with the -n option

## List the pods in the kube-system namespace:
```
kubectl -n kube-system get pods
```
```
[node1 kubelabs]$ kubectl get pods -n kube-system
NAME                            READY   STATUS    RESTARTS   AGE
coredns-6dcc67dcbc-4sw6m        1/1     Running   0          2m15s
coredns-6dcc67dcbc-x4qnk        1/1     Running   0          2m15s
etcd-node1                      1/1     Running   0          108s
kube-apiserver-node1            1/1     Running   0          84s
kube-controller-manager-node1   1/1     Running   0          104s
kube-proxy-9gljr                1/1     Running   0          2m5s
kube-proxy-9zktt                1/1     Running   0          2m15s
kube-proxy-qvqrf                1/1     Running   0          107s
kube-scheduler-node1            1/1     Running   0          105s
weave-net-78bxz                 2/2     Running   0          2m15s
weave-net-g2cf6                 2/2     Running   0          2m5s
weave-net-hxqd9                 0/2     Evicted   0          19s
```
Ejecutamos el comando anterior "kubectl -n kube-system get pods" este comando nos ayudará a inspeccionar y desplegar las aplicaciones que tiene nuestro cluster como se muestra en la imagen.
![Esta es una imagen de ejemplo](get%20pods.png)<br>

## What are all these pods? 
- etcd is our etcd server
- kube-apiserver is the API server
- kube-controller-manager and kube-scheduler are other master components
- kube-dns is an additional component (not mandatory but super useful, so it’s there)
- kube-proxy is the (per-node) component managing port mappings and such
- weave is the (per-node) component managing the network overlay

The ```READY``` column indicates the number of containers in each pod. Pods with a name ending with ```-node1``` are the master components (they have been specifically “pinned” to the master node).

5. Ejecución del Portainer
# Running Portainer on 5-Node Kubernetes Cluster

- Los requisitos son estar en "Play with Kubernetes" y haber configurado 5 nodos en un cluster como lo hicimos anteriormente. 
## Pre-requisite:

- Play with Kubernetes Platform
- Set up 5 Node Kubernetes Cluster


## Run the below command:

```
kubectl apply -f https://raw.githubusercontent.com/portainer/portainer-k8s/master/portainer-nodeport.yaml
```

## Verify

```
[node1 kubelabs]$ kubectl get po,svc,deploy -n portainer
NAME                             READY   STATUS    RESTARTS   AGE
pod/portainer-58767884bc-jqfnn   1/1     Running   2          13m

NAME                TYPE       CLUSTER-IP       EXTERNAL-IP   PORT(S)                         AGE
service/portainer   NodePort   10.111.121.188   <none>        9000:30777/TCP,8000:30776/TCP   13m

NAME                        READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/portainer   1/1     1            1           13m
[node1 kubelabs]$
```
Al ejecutar el comando anterior con la URL nos arroja información de la aplicación, asi como el numero de puerto en donde podremos desplegar la pagina para probarlo.
![Esta es una imagen de ejemplo](verify.png)<br>
## Opening up Browser

Go to browser and add the port in the following manner:

```
https://ip172-18-0-7-bs6kb2bmjflg00fa5g4g-<ADD 30777 HERE>.direct.labs.play-with-k8s.com/
```
### Lamentablemente tuvimos este unico detalle, ya que "Play with Kubernetes" no nos otorgó el acceso a los puertos y por esta razón nos fue imposible poder desplegar la pagina web y poder concluir de manera satisfactoria la practica.

## Importancia de Kubernetes para aplicaciones de soluciones IaaS
Kubernetes es una plataforma open source que sirve para administrar cargas de trabajo y servicios, lo que facilita la automatización y eliminación de una gran cantidad de los procesos manuales durante la puesta en marcha y escalabilidad de las aplicaciones en contenedores.<br>
Ofrece una mayor flexibilidad en la infraestructura como servicio (IaaS), lo que permite la portabilidad entre proveedores de infraestructuras. Además se puede extender en diversos entornos cloud y soportar innumerables runtimes de contenedores.

# Conclusiones
- Puedo decir que al realizar esta practica pudimos comprender de mejor manera que en un clúster de Kubernetes, los nodos son las máquinas virtuales o servidores que ejecutan las aplicaciones y flujos de trabajo en la nube. El nodo master de Kubernetes controla cada nodo, por lo que en raras ocasiones interactuarás con los nodos directamente.<br>
- Algo que puedo decir al haber realizado la practica es que en cuanto a  los nodos, un nodo master necesita almenos un nodo hijo, y a estos se le pueden implementar los "pods" ya que estos ayudan a organizarce y progrmarce entre ellos, ademas si es necesario ampliar la capacidad del cluster solo es necesario incorporar mas nodos y el problema estará resuelto. Cabe mencionar que es muy eficaz trabajar con "Play  with kubernetes" ya que podemos realizar casi cualquier tipo de pruebas y esto nos ayuda a mejorar o a despejar las dudas que puedan surgir.

# Fuentes de Información
- “Customizing DNS Service,” Kubernetes. 10-Ago-2021. Obtenido de: https://kubernetes.io/docs/tasks/administer-cluster/dns-custom-nameservers/.
- “Introducción a la arquitectura de Kubernetes,” Redhat.com. 2016. Obtenido de: https://www.redhat.com/es/topics/containers/kubernetes-architecture.
- “kube-controller-manager,” Kubernetes. 08-Dic-2021. Obtenido de: https://kubernetes.io/docs/reference/command-line-tools-reference/kube-controller-manager/.
- “Pod,” Google Cloud. 28-Feb-2022. Obtenido de: https://cloud.google.com/kubernetes-engine/docs/concepts/pod?hl=es-419.
- “Nodos,” Kubernetes. 14-Jun-2020. Obtenido de: https://kubernetes.io/es/docs/concepts/architecture/nodes/.
- “Tutorial de Kubernetes: primeros pasos,” IONOS Digitalguide. 27-Nov-2020. Obtenido de: https://www.ionos.mx/digitalguide/servidores/configuracion/tutorial-de-kubernetes/. 
- “Introducción a Kubernetes para principiantes,” Geekflare, 15-Dec-2019. Obtenido de: https://geekflare.com/es/kubernetes-introduction/.
- J. A. O. Carvajal, “Primeros pasos con Kubernetes,” Adictos al trabajo, 25-Apr-2016. Obtenido de: https://www.adictosaltrabajo.com/2016/04/25/primeros-pasos-con-kubernetes/.

# Anexos
### Evidencias de trabajo colaborativo.
![Esta es una imagen de ejemplo](Evidencia.png)<br>
![Esta es una imagen de ejemplo](Evidencia2.png)<br>
![Esta es una imagen de ejemplo](Evidencia3.png)<br>
![Esta es una imagen de ejemplo](Evidencia4.png)<br>
![Esta es una imagen de ejemplo](Evidencia5.png)<br>
